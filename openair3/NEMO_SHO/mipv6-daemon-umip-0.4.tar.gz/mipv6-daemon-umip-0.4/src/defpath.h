#define DEFAULT_CONFIG_FILE "/usr/local/etc/mip6d.conf"
